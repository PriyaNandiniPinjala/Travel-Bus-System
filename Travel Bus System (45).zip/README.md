
  # Travel Bus System

  This is a code bundle for Travel Bus System. The original project is available at https://www.figma.com/design/V5EamJxeF0St88LcFPYIWV/Travel-Bus-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  