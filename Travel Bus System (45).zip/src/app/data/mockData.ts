import { Bus, Booking, Seat } from "../types";

export const cities = [
  "London",
  "Manchester",
  "Birmingham",
  "Leeds",
  "Glasgow",
  "Liverpool",
  "Newcastle",
  "Sheffield",
  "Bristol",
  "Edinburgh",
  "Cardiff",
  "Belfast",
  "Oxford",
  "Cambridge",
  "Brighton"
];

export const mockBuses: Bus[] = [
  {
    id: "1",
    operator: "National Express",
    busType: "Standard Coach",
    departureTime: "09:00",
    arrivalTime: "14:30",
    duration: "5h 30m",
    price: 28,
    availableSeats: 12,
    totalSeats: 40,
    rating: 4.5,
    amenities: ["WiFi", "Charging Port", "Water", "Toilet"],
    from: "London",
    to: "Manchester"
  },
  {
    id: "2",
    operator: "Megabus",
    busType: "Economy Coach",
    departureTime: "10:30",
    arrivalTime: "15:45",
    duration: "5h 15m",
    price: 18,
    availableSeats: 8,
    totalSeats: 40,
    rating: 4.2,
    amenities: ["WiFi", "Charging Port"],
    from: "London",
    to: "Manchester"
  },
  {
    id: "3",
    operator: "FlixBus",
    busType: "Premium Coach",
    departureTime: "13:00",
    arrivalTime: "19:00",
    duration: "6h 0m",
    price: 35,
    availableSeats: 15,
    totalSeats: 35,
    rating: 4.8,
    amenities: ["WiFi", "Charging Port", "Water", "Toilet", "Snacks", "Entertainment"],
    from: "London",
    to: "Manchester"
  },
  {
    id: "4",
    operator: "Stagecoach",
    busType: "Standard Coach",
    departureTime: "07:00",
    arrivalTime: "13:30",
    duration: "6h 30m",
    price: 22,
    availableSeats: 20,
    totalSeats: 45,
    rating: 3.8,
    amenities: ["Toilet"],
    from: "London",
    to: "Manchester"
  },
  {
    id: "5",
    operator: "National Express",
    busType: "Sleeper Coach",
    departureTime: "23:00",
    arrivalTime: "05:00",
    duration: "6h 0m",
    price: 32,
    availableSeats: 10,
    totalSeats: 40,
    rating: 4.6,
    amenities: ["WiFi", "Charging Port", "Water", "Toilet"],
    from: "London",
    to: "Manchester"
  },
];

export const generateSeats = (totalSeats: number, availableSeats: number): Seat[] => {
  const seats: Seat[] = [];
  const bookedCount = totalSeats - availableSeats;
  const bookedSeatNumbers = new Set<number>();
  
  // Randomly select seats to be booked
  while (bookedSeatNumbers.size < bookedCount) {
    bookedSeatNumbers.add(Math.floor(Math.random() * totalSeats) + 1);
  }
  
  for (let i = 1; i <= totalSeats; i++) {
    const row = Math.floor((i - 1) / 4);
    const col = (i - 1) % 4;
    
    let type: 'window' | 'aisle' | 'middle';
    if (col === 0 || col === 3) {
      type = 'window';
    } else if (col === 1) {
      type = 'aisle';
    } else {
      type = 'middle';
    }
    
    seats.push({
      id: `seat-${i}`,
      number: i,
      row,
      type,
      isBooked: bookedSeatNumbers.has(i)
    });
  }
  
  return seats;
};

export const mockBookings: Booking[] = [
  {
    id: "BK001",
    busId: "1",
    operator: "National Express",
    from: "London",
    to: "Manchester",
    date: "2026-03-28",
    departureTime: "09:00",
    arrivalTime: "14:30",
    passengers: [
      { name: "John Smith", age: 32, gender: "Male", seatNumber: 5 },
      { name: "Jane Smith", age: 28, gender: "Female", seatNumber: 6 }
    ],
    totalPrice: 56,
    bookingDate: "2026-03-20",
    status: "confirmed"
  }
];
