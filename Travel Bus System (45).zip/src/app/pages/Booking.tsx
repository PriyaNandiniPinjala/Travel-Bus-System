import { useState, useEffect } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router";
import { ArrowLeft, User, CreditCard, Lock, Bus as BusIcon } from "lucide-react";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { mockBuses, generateSeats } from "../data/mockData";
import { Seat, Passenger } from "../types";
import { RadioGroup, RadioGroupItem } from "../components/ui/radio-group";

export function Booking() {
  const navigate = useNavigate();
  const { busId } = useParams();
  const [searchParams] = useSearchParams();
  const date = searchParams.get("date");

  const bus = mockBuses.find((b) => b.id === busId);
  const [seats, setSeats] = useState<Seat[]>([]);
  const [selectedSeats, setSelectedSeats] = useState<number[]>([]);
  const [passengers, setPassengers] = useState<Passenger[]>([]);
  const [showPayment, setShowPayment] = useState(false);
  
  // Payment state
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [cardNumber, setCardNumber] = useState("");
  const [cardName, setCardName] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");

  useEffect(() => {
    if (bus) {
      setSeats(generateSeats(bus.totalSeats, bus.availableSeats));
    }
  }, [bus]);

  if (!bus) {
    return <div>Bus not found</div>;
  }

  const handleSeatClick = (seat: Seat) => {
    if (seat.isBooked) return;

    if (selectedSeats.includes(seat.number)) {
      setSelectedSeats(selectedSeats.filter((s) => s !== seat.number));
      setPassengers(passengers.filter((p) => p.seatNumber !== seat.number));
    } else {
      setSelectedSeats([...selectedSeats, seat.number]);
      setPassengers([
        ...passengers,
        { name: "", age: 0, gender: "", seatNumber: seat.number },
      ]);
    }
  };

  const handlePassengerChange = (
    seatNumber: number,
    field: keyof Passenger,
    value: string | number
  ) => {
    setPassengers(
      passengers.map((p) =>
        p.seatNumber === seatNumber ? { ...p, [field]: value } : p
      )
    );
  };

  const handleProceedToPayment = () => {
    if (passengers.some((p) => !p.name || !p.age || !p.gender)) {
      alert("Please fill in all passenger details");
      return;
    }
    setShowPayment(true);
  };

  const handleCompletePayment = () => {
    // Validate payment details
    if (paymentMethod === "card") {
      if (!cardNumber || !cardName || !expiryDate || !cvv) {
        alert("Please fill in all payment details");
        return;
      }
    }

    const booking = {
      id: `BK${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      busId: bus.id,
      operator: bus.operator,
      from: bus.from,
      to: bus.to,
      date: date || "",
      departureTime: bus.departureTime,
      arrivalTime: bus.arrivalTime,
      passengers,
      totalPrice: bus.price * selectedSeats.length,
      bookingDate: new Date().toISOString(),
      status: "confirmed" as const,
    };

    // Store in localStorage
    const existingBookings = JSON.parse(
      localStorage.getItem("bookings") || "[]"
    );
    localStorage.setItem(
      "bookings",
      JSON.stringify([...existingBookings, booking])
    );

    navigate(`/confirmation/${booking.id}`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <BusIcon className="w-6 h-6 text-blue-600" />
              <span className="text-xl font-bold">BusTravel</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Seat Selection */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Select Seats</CardTitle>
                <p className="text-sm text-gray-600">
                  Click on available seats to select
                </p>
              </CardHeader>
              <CardContent>
                {/* Legend */}
                <div className="flex flex-wrap gap-4 mb-6 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 border-2 border-gray-300 rounded"></div>
                    <span>Available</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-blue-600 rounded"></div>
                    <span>Selected</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-gray-300 rounded"></div>
                    <span>Booked</span>
                  </div>
                </div>

                {/* Seat Layout */}
                <div className="bg-gray-100 p-6 rounded-lg">
                  <div className="mb-4 text-center">
                    <div className="inline-block bg-gray-800 text-white px-4 py-2 rounded-t-lg">
                      Driver
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-3">
                    {seats.map((seat) => (
                      <button
                        key={seat.id}
                        onClick={() => handleSeatClick(seat)}
                        disabled={seat.isBooked}
                        className={`
                          w-full aspect-square rounded-lg border-2 font-semibold text-sm
                          transition-all flex items-center justify-center
                          ${
                            seat.isBooked
                              ? "bg-gray-300 cursor-not-allowed border-gray-400 text-gray-600"
                              : selectedSeats.includes(seat.number)
                              ? "bg-blue-600 text-white border-blue-700 scale-95"
                              : "border-gray-300 hover:border-blue-400 hover:bg-blue-50"
                          }
                        `}
                      >
                        {seat.number}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <p className="font-semibold">
                    Selected Seats: {selectedSeats.length}
                  </p>
                  <p className="text-sm text-gray-600">
                    Seat Numbers: {selectedSeats.join(", ") || "None"}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Passenger Details */}
          <div className="space-y-6">
            {/* Trip Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Trip Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Operator:</span>
                  <span className="font-semibold">{bus.operator}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Route:</span>
                  <span className="font-semibold">
                    {bus.from} → {bus.to}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Date:</span>
                  <span className="font-semibold">
                    {new Date(date || "").toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Departure:</span>
                  <span className="font-semibold">{bus.departureTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Price per seat:</span>
                  <span className="font-semibold">£{bus.price}</span>
                </div>
                <div className="border-t pt-2 mt-2 flex justify-between text-lg">
                  <span className="font-bold">Total:</span>
                  <span className="font-bold text-blue-600">
                    £{bus.price * selectedSeats.length}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Passenger Form */}
            {passengers.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Passenger Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {passengers.map((passenger, index) => (
                    <div
                      key={passenger.seatNumber}
                      className="p-4 border rounded-lg space-y-4"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">
                          Passenger {index + 1} (Seat {passenger.seatNumber})
                        </h4>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`name-${passenger.seatNumber}`}>
                          Full Name
                        </Label>
                        <Input
                          id={`name-${passenger.seatNumber}`}
                          value={passenger.name}
                          onChange={(e) =>
                            handlePassengerChange(
                              passenger.seatNumber,
                              "name",
                              e.target.value
                            )
                          }
                          placeholder="Enter full name"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor={`age-${passenger.seatNumber}`}>
                            Age
                          </Label>
                          <Input
                            id={`age-${passenger.seatNumber}`}
                            type="number"
                            value={passenger.age || ""}
                            onChange={(e) =>
                              handlePassengerChange(
                                passenger.seatNumber,
                                "age",
                                parseInt(e.target.value)
                              )
                            }
                            placeholder="Age"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor={`gender-${passenger.seatNumber}`}>
                            Gender
                          </Label>
                          <select
                            id={`gender-${passenger.seatNumber}`}
                            value={passenger.gender}
                            onChange={(e) =>
                              handlePassengerChange(
                                passenger.seatNumber,
                                "gender",
                                e.target.value
                              )
                            }
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          >
                            <option value="">Select</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Payment Form */}
            {showPayment && (
              <Card>
                <CardHeader>
                  <CardTitle>Payment Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <RadioGroup
                    value={paymentMethod}
                    onValueChange={setPaymentMethod}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="card" />
                      <Label>Card Payment</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="paypal" />
                      <Label>PayPal</Label>
                    </div>
                  </RadioGroup>

                  {paymentMethod === "card" && (
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="cardNumber">Card Number</Label>
                        <Input
                          id="cardNumber"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          placeholder="1234 5678 9012 3456"
                          maxLength={19}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="cardName">Cardholder Name</Label>
                        <Input
                          id="cardName"
                          value={cardName}
                          onChange={(e) => setCardName(e.target.value)}
                          placeholder="Enter cardholder name"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="expiryDate">Expiry Date</Label>
                          <Input
                            id="expiryDate"
                            value={expiryDate}
                            onChange={(e) => setExpiryDate(e.target.value)}
                            placeholder="MM/YY"
                            maxLength={5}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="cvv">CVV</Label>
                          <Input
                            id="cvv"
                            type="password"
                            value={cvv}
                            onChange={(e) => setCvv(e.target.value)}
                            placeholder="123"
                            maxLength={4}
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {paymentMethod === "paypal" && (
                    <div className="p-6 bg-blue-50 rounded-lg text-center">
                      <CreditCard className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                      <p className="text-sm text-gray-600">
                        You will be redirected to PayPal to complete your payment
                      </p>
                    </div>
                  )}

                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
                    <Lock className="w-5 h-5 text-green-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold text-green-900">Secure Payment</p>
                      <p className="text-xs text-green-700">Your payment information is encrypted and secure</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Action Buttons */}
            {selectedSeats.length > 0 && !showPayment && (
              <Button
                className="w-full"
                size="lg"
                onClick={handleProceedToPayment}
              >
                Proceed to Payment (£{bus.price * selectedSeats.length})
              </Button>
            )}

            {/* Complete Payment Button */}
            {showPayment && (
              <Button
                className="w-full"
                size="lg"
                onClick={handleCompletePayment}
              >
                <Lock className="w-4 h-4 mr-2" />
                Complete Payment (£{bus.price * selectedSeats.length})
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}