import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router";
import { ArrowLeft, Clock, Star, Wifi, BatteryCharging, Droplet, Armchair, Users, Bus as BusIcon } from "lucide-react";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { mockBuses } from "../data/mockData";
import { Bus } from "../types";

export function SearchResults() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const from = searchParams.get("from");
  const to = searchParams.get("to");
  const date = searchParams.get("date");

  // In a real app, filter buses based on search params
  const [buses] = useState<Bus[]>(mockBuses);
  const [sortBy, setSortBy] = useState<"price" | "departure" | "rating">("departure");

  const sortedBuses = [...buses].sort((a, b) => {
    if (sortBy === "price") return a.price - b.price;
    if (sortBy === "rating") return b.rating - a.rating;
    return a.departureTime.localeCompare(b.departureTime);
  });

  const getAmenityIcon = (amenity: string) => {
    switch (amenity.toLowerCase()) {
      case "wifi":
        return <Wifi className="w-4 h-4" />;
      case "charging port":
        return <BatteryCharging className="w-4 h-4" />;
      case "water":
        return <Droplet className="w-4 h-4" />;
      case "blanket":
        return <Armchair className="w-4 h-4" />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <BusIcon className="w-6 h-6 text-blue-600" />
              <span className="text-xl font-bold">BusTravel</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Summary */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">
                {from} → {to}
              </h2>
              <p className="text-gray-600 mt-1">
                {new Date(date || "").toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="departure">Departure Time</option>
                <option value="price">Price</option>
                <option value="rating">Rating</option>
              </select>
            </div>
          </div>
        </div>

        {/* Bus List */}
        <div className="space-y-4">
          <p className="text-gray-600">{buses.length} buses found</p>
          {sortedBuses.map((bus) => (
            <Card key={bus.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardContent className="p-0">
                <div className="flex flex-col lg:flex-row">
                  {/* Bus Info */}
                  <div className="flex-1 p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">
                          {bus.operator}
                        </h3>
                        <p className="text-gray-600">{bus.busType}</p>
                      </div>
                      <div className="flex items-center gap-1 bg-green-100 px-2 py-1 rounded">
                        <Star className="w-4 h-4 text-green-600 fill-green-600" />
                        <span className="font-semibold text-green-600">
                          {bus.rating}
                        </span>
                      </div>
                    </div>

                    {/* Timing */}
                    <div className="flex items-center gap-4 mb-4">
                      <div>
                        <p className="text-2xl font-bold">{bus.departureTime}</p>
                        <p className="text-sm text-gray-600">{from}</p>
                      </div>
                      <div className="flex-1 flex flex-col items-center">
                        <p className="text-sm text-gray-600 mb-1">{bus.duration}</p>
                        <div className="w-full h-0.5 bg-gray-300"></div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold">{bus.arrivalTime}</p>
                        <p className="text-sm text-gray-600">{to}</p>
                      </div>
                    </div>

                    {/* Amenities */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {bus.amenities.map((amenity, index) => (
                        <Badge
                          key={index}
                          variant="secondary"
                          className="flex items-center gap-1"
                        >
                          {getAmenityIcon(amenity)}
                          {amenity}
                        </Badge>
                      ))}
                    </div>

                    {/* Seats Available */}
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="w-4 h-4 text-gray-600" />
                      <span className="text-gray-600">
                        {bus.availableSeats} seats available
                      </span>
                    </div>
                  </div>

                  {/* Price & Booking */}
                  <div className="lg:w-48 bg-gray-50 p-6 flex flex-col items-center justify-center border-t lg:border-t-0 lg:border-l">
                    <p className="text-sm text-gray-600 mb-1">Starting from</p>
                    <p className="text-3xl font-bold text-blue-600 mb-4">
                      ${bus.price}
                    </p>
                    <Button
                      className="w-full"
                      onClick={() => navigate(`/booking/${bus.id}?date=${date}`)}
                    >
                      View Seats
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
