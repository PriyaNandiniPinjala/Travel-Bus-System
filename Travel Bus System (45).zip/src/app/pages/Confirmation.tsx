import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router";
import { CheckCircle, Download, Share2, ArrowLeft, MapPin, Calendar, Clock, User, Bus as BusIcon } from "lucide-react";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { Booking } from "../types";

export function Confirmation() {
  const navigate = useNavigate();
  const { bookingId } = useParams();
  const [booking, setBooking] = useState<Booking | null>(null);

  useEffect(() => {
    const storedBookings = JSON.parse(localStorage.getItem("bookings") || "[]");
    const foundBooking = storedBookings.find((b: Booking) => b.id === bookingId);
    setBooking(foundBooking || null);
  }, [bookingId]);

  if (!booking) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="py-12 text-center">
            <p className="text-xl mb-4">Booking not found</p>
            <Button onClick={() => navigate("/")}>Go to Home</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleDownload = () => {
    alert("Ticket download functionality would be implemented here");
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: "Bus Ticket",
        text: `My bus ticket from ${booking.from} to ${booking.to}`,
      });
    } else {
      alert("Share functionality would be implemented here");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2">
              <BusIcon className="w-6 h-6 text-blue-600" />
              <span className="text-xl font-bold">BusTravel</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Success Message */}
        <div className="text-center mb-8">
          <div className="inline-block p-4 bg-green-100 rounded-full mb-4">
            <CheckCircle className="w-16 h-16 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Booking Confirmed!
          </h1>
          <p className="text-gray-600">
            Your ticket has been booked successfully
          </p>
        </div>

        {/* Ticket */}
        <Card className="overflow-hidden shadow-xl">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm opacity-90">Booking ID</p>
                <p className="text-2xl font-bold">{booking.id}</p>
              </div>
              <div className="text-right">
                <p className="text-sm opacity-90">Status</p>
                <p className="text-lg font-semibold">CONFIRMED</p>
              </div>
            </div>
          </div>

          <CardContent className="p-6 space-y-6">
            {/* Operator */}
            <div>
              <h2 className="text-2xl font-bold text-gray-900">
                {booking.operator}
              </h2>
            </div>

            {/* Route */}
            <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg">
              <MapPin className="w-6 h-6 text-blue-600" />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-xl font-bold">{booking.from}</span>
                  <span className="text-gray-400">→</span>
                  <span className="text-xl font-bold">{booking.to}</span>
                </div>
              </div>
            </div>

            {/* Date & Time */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3 mb-2">
                  <Calendar className="w-5 h-5 text-gray-600" />
                  <span className="text-sm text-gray-600">Journey Date</span>
                </div>
                <p className="text-lg font-semibold">
                  {new Date(booking.date).toLocaleDateString("en-US", {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>

              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3 mb-2">
                  <Clock className="w-5 h-5 text-gray-600" />
                  <span className="text-sm text-gray-600">Departure Time</span>
                </div>
                <p className="text-lg font-semibold">{booking.departureTime}</p>
                <p className="text-sm text-gray-600">
                  Arrival: {booking.arrivalTime}
                </p>
              </div>
            </div>

            {/* Passengers */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <User className="w-5 h-5 text-gray-600" />
                <h3 className="font-semibold text-lg">
                  Passenger Details ({booking.passengers.length})
                </h3>
              </div>
              <div className="space-y-3">
                {booking.passengers.map((passenger, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div>
                      <p className="font-semibold text-lg">{passenger.name}</p>
                      <p className="text-sm text-gray-600">
                        {passenger.age} years • {passenger.gender}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">Seat Number</p>
                      <p className="text-2xl font-bold text-blue-600">
                        {passenger.seatNumber}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Booking Details */}
            <div className="border-t pt-4">
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Booked on</span>
                <span className="font-semibold">
                  {new Date(booking.bookingDate).toLocaleDateString()}
                </span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Number of Passengers</span>
                <span className="font-semibold">{booking.passengers.length}</span>
              </div>
              <div className="flex justify-between text-xl font-bold mt-4 pt-4 border-t">
                <span>Total Amount Paid</span>
                <span className="text-blue-600">${booking.totalPrice}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-4 pt-4">
              <Button variant="outline" onClick={handleDownload} className="w-full">
                <Download className="w-4 h-4 mr-2" />
                Download Ticket
              </Button>
              <Button variant="outline" onClick={handleShare} className="w-full">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
            </div>

            <div className="text-center pt-4">
              <Button onClick={() => navigate("/my-bookings")} className="w-full sm:w-auto">
                View All Bookings
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Important Info */}
        <Card className="mt-6 bg-amber-50 border-amber-200">
          <CardContent className="p-4">
            <h4 className="font-semibold mb-2">Important Information</h4>
            <ul className="text-sm space-y-1 text-gray-700">
              <li>• Please arrive at the boarding point 15 minutes before departure</li>
              <li>• Carry a valid ID proof along with this ticket</li>
              <li>• Cancellation allowed up to 2 hours before departure</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
