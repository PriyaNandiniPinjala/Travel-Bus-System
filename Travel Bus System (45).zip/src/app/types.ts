export interface Bus {
  id: string;
  operator: string;
  busType: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  price: number;
  availableSeats: number;
  totalSeats: number;
  rating: number;
  amenities: string[];
  from: string;
  to: string;
}

export interface Seat {
  id: string;
  number: number;
  row: number;
  type: 'window' | 'aisle' | 'middle';
  isBooked: boolean;
}

export interface Passenger {
  name: string;
  age: number;
  gender: string;
  seatNumber: number;
}

export interface Booking {
  id: string;
  busId: string;
  operator: string;
  from: string;
  to: string;
  date: string;
  departureTime: string;
  arrivalTime: string;
  passengers: Passenger[];
  totalPrice: number;
  bookingDate: string;
  status: 'confirmed' | 'cancelled';
}
