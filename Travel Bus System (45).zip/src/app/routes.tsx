import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { SearchResults } from "./pages/SearchResults";
import { Booking } from "./pages/Booking";
import { MyBookings } from "./pages/MyBookings";
import { Confirmation } from "./pages/Confirmation";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/search",
    Component: SearchResults,
  },
  {
    path: "/booking/:busId",
    Component: Booking,
  },
  {
    path: "/my-bookings",
    Component: MyBookings,
  },
  {
    path: "/confirmation/:bookingId",
    Component: Confirmation,
  },
]);
